package com.example.designpatterns.factory;

/**
 * Interfaz que define la operación para mostrar la información del proyecto.
 */
public interface Project {
    void displayInfo();
}
